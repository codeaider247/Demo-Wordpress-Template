<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><link rel="stylesheet" href="style.css"><title>Demo Project</title><?php wp_head(); ?> </head><body>

    <!-- storyteller Portion Start -->
    <header id="firstContainer"><!--          Navbar Start         --><div id="navbar">
            <div id="logo"><a href="#">UNICORN</a></div>
            <div id="menu">
                <li><a href="#" id="home">HOME</a></li>
                <li><a href="#" id="about">ABOUT</a></li>
                <li><a href="#" id="stories">STORIES</a></li>
                <li><a href="#" id="hello">HELLO</a></li>
            </div>
        </div>
        <!--          Navbar Start         -->

        <div id="storyTeller">
            <h1>STORYTELLER</h1>
            <div id="lineM"><div id="line"></div></div>
            <div id="story"><p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Eaque, itaque eius vero quaerat esse veniam. Cupiditate maiores similique repudiandae aut, labore nemo sit officiis soluta illum eius optio, vel nobis! Lorem ipsum dolor, sit amet consectetur adipisicing elit.</p></div>
            <button id="rest">read the rest</button>
        </div>
    </header>