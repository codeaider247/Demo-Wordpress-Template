<?php
    get_header();
?>

<?php
    get_template_part( 'template-parts/tpl-index' );
?>

<?php
    //get footer.php file
    get_footer();
?>
              